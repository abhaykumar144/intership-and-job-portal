package com.zidio.portal.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import com.zidio.portal.repository.ApplicationRepository;
import com.zidio.portal.model.ApplicationEntity;
import java.util.List;

@RestController
@RequestMapping("/api/applications")
public class ApplicationController {
    @Autowired
    private ApplicationRepository repo;

    @GetMapping
    public List<ApplicationEntity> all() { return repo.findAll(); }

    @PostMapping
    public ApplicationEntity apply(@RequestBody ApplicationEntity a) {
        a.setStatus("APPLIED");
        return repo.save(a);
    }
}
