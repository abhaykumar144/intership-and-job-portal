package com.zidio.portal.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import com.zidio.portal.repository.JobRepository;
import com.zidio.portal.model.Job;
import java.util.List;

@RestController
@RequestMapping("/api/jobs")
public class JobController {
    @Autowired
    private JobRepository repo;

    @GetMapping
    public List<Job> all() { return repo.findAll(); }

    @GetMapping("/{id}")
    public Job get(@PathVariable Long id) { return repo.findById(id).orElse(null); }

    @PostMapping
    public Job create(@RequestBody Job j) { return repo.save(j); }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) { repo.deleteById(id); }
}
