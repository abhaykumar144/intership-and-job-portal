package com.zidio.portal.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import com.zidio.portal.repository.UserRepository;
import com.zidio.portal.model.User;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/users")
public class UserController {
    @Autowired
    private UserRepository repo;

    @GetMapping
    public List<User> all() { return repo.findAll(); }

    @PostMapping("/register")
    public User register(@RequestBody User u) { return repo.save(u); }

    @PostMapping("/login")
    public String login(@RequestBody User u) {
        Optional<User> found = repo.findByEmail(u.getEmail());
        if (found.isPresent() && found.get().getPassword().equals(u.getPassword())) {
            return "OK";
        }
        return "INVALID";
    }
}
