package com.zidio.portal.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import com.zidio.portal.repository.JobRepository;
import com.zidio.portal.model.Job;

@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private JobRepository jobRepository;

    @Override
    public void run(String... args) throws Exception {
        jobRepository.save(Job.builder()
            .title("Java Spring Boot Internship")
            .description("Work on backend APIs using Spring Boot.")
            .location("Remote")
            .type("Internship")
            .companyId(1L)
            .build());

        jobRepository.save(Job.builder()
            .title("Frontend Developer (React)")
            .description("Build responsive UI using React.")
            .location("Bengaluru")
            .type("Full-time")
            .companyId(2L)
            .build());
    }
}
