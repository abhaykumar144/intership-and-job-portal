package com.zidio.portal.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.zidio.portal.model.ApplicationEntity;
import java.util.List;

public interface ApplicationRepository extends JpaRepository<ApplicationEntity, Long> {
    List<ApplicationEntity> findByUserId(Long userId);
    List<ApplicationEntity> findByJobId(Long jobId);
}
