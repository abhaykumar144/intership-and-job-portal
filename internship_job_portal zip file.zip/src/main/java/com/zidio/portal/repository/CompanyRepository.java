package com.zidio.portal.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.zidio.portal.model.Company;

public interface CompanyRepository extends JpaRepository<Company, Long> {
}
