# Internship & Job Portal - Zidio (Skeleton Project)

This is a minimal **Java Spring Boot** skeleton for an Internship and Job Portal suitable for an internship submission.
It uses **H2 in-memory database** so you can run it without installing a separate database.

## What's included
- Spring Boot backend (REST APIs)
- Entities: User, Company, Job, Application
- Basic controllers for Users, Jobs, and Applications
- Static frontend (simple index.html in resources/static)
- H2 console enabled at /h2-console

## How to run
1. Make sure you have Java 11+ and Maven installed.
2. From the project root, run:
   ```
   mvn spring-boot:run
   ```
3. Open http://localhost:8080 to see the static page.
4. H2 console: http://localhost:8080/h2-console
   - JDBC URL: jdbc:h2:mem:jobportaldb
   - User: sa
   - Password: (leave blank)

## Notes
- This is a skeleton to help you start. You should expand features: authentication, file uploads (resumes), pagination, company dashboards, admin features, UI using React/Angular, and deployment steps.
- If you want, I can extend this to include React frontend, JWT auth, or MySQL configuration.

Good luck with your internship submission! - Abhay's assistant
