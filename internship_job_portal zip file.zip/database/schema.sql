-- This project uses JPA auto-ddl. If you wish to create schema manually, use this SQL as a guideline.

CREATE TABLE USER (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255),
  email VARCHAR(255),
  password VARCHAR(255),
  role VARCHAR(50)
);

CREATE TABLE COMPANY (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255),
  email VARCHAR(255),
  description VARCHAR(2000)
);

CREATE TABLE JOB (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255),
  description VARCHAR(2000),
  location VARCHAR(255),
  type VARCHAR(100),
  company_id BIGINT
);

CREATE TABLE APPLICATION_ENTITY (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  job_id BIGINT,
  user_id BIGINT,
  status VARCHAR(50)
);
